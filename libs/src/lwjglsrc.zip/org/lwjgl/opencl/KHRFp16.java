/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opencl;

import org.lwjgl.*;
import java.nio.*;

public final class KHRFp16 {

	/**
	 * cl_device_info 
	 */
	public static final int CL_DEVICE_HALF_FP_CONFIG = 0x1033;

	private KHRFp16() {}
}
