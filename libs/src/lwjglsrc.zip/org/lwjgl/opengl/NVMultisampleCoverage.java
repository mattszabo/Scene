/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVMultisampleCoverage {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetDoublev,
	 *  GetIntegerv, and GetFloatv:
	 */
	public static final int GL_COVERAGE_SAMPLES_NV = 0x80A9,
		GL_COLOR_SAMPLES_NV = 0x8E20;

	private NVMultisampleCoverage() {}
}
