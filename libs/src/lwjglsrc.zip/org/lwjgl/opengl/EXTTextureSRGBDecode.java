/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTTextureSRGBDecode {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of TexParameterf, TexParameteri,
	 *  GetTexParameterfv, GetTexParameteriv, SamplerParameteri,
	 *  SamplerParameterf, SamplerParameteriv, SamplerParameterfv,
	 *  SamplerParameterIiv, SamplerParameterIuiv, GetSamplerParameteriv,
	 *  GetSamplerParameterfv, GetSamplerParameterIiv, and GetSamplerParameterIuiv:
	 */
	public static final int GL_TEXTURE_SRGB_DECODE_EXT = 0x8A48;

	/**
	 *  Accepted by the &lt;enum&gt; parameter of TexParameterf, TexParameteri,
	 *  SamplerParameteri, SamplerParameterf, SamplerParameteriv, SamplerParameterfv,
	 *  SamplerParameterIiv and SamplerParameterIuiv:
	 */
	public static final int GL_DECODE_EXT = 0x8A49,
		GL_SKIP_DECODE_EXT = 0x8A4A;

	private EXTTextureSRGBDecode() {}
}
