/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class SUNSliceAccum {

	/**
	 *  Accepted by the &lt;op&gt; parameter of Accum,
	 */
	public static final int GL_SLICE_ACCUM_SUN = 0x85CC;

	private SUNSliceAccum() {}
}
