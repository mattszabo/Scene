/*******************************************************************************
 * Copyright (c) 2010 Jens von Pilgrim and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Project:	org.lwjgl
 * File:  	Activator.java
 * Date: 	Nov 23, 2010
 ******************************************************************************/
package org.lwjgl.eclipse;

import java.io.File;
import java.net.URL;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Plugin;
import org.eclipse.core.runtime.Status;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.BundleException;

/**
 * The activator class controls the plug-in life cycle
 */
public class Activator extends Plugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "org.lwjgl";

	public static String[] NATIVEPATH = new String[] { "windows", "macosx",
			"linux", "solaris" };

	// The shared instance
	private static Activator plugin;

	/**
	 * The constructor
	 */
	public Activator() {
		plugin = this;
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.core.runtime.Plugins#start(org.osgi.framework.BundleContext)
	 */
	@Override
	public void start(BundleContext context) throws Exception {
		
		super.start(context);

		int iOS = -1;
		String osname = System.getProperty("os.name").toLowerCase();
		String osarch = System.getProperty("os.arch").toLowerCase();

		if (osname.startsWith("windows") && osarch.startsWith("x86")) {
			iOS = 0;
		} else if (osname.startsWith("mac")) {
			iOS = 1;
		} else if (osname.startsWith("linux")) {
			iOS = 2;
		} else if (osname.startsWith("solaris")) {
			iOS = 3;
		}
		
		if (iOS >= 0) {
			String base = "native" + File.separator + NATIVEPATH[iOS];
			try {
				
				Bundle fragment = context.getBundle();
				
				URL url = FileLocator.resolve(fragment.getEntry(base));
				File fileDir = new File(url.getPath());
				System.setProperty("org.lwjgl.librarypath", fileDir.getPath());

				Status status = new Status(Status.INFO, PLUGIN_ID, Status.INFO,
						"Set org.lwjgl.librarypath to " + fileDir.getPath()
								+ ", OS: " + osname + "(" + osarch + ")", null);
				getLog().log(status);

			} catch (Throwable ex) {
				Status status = new Status(Status.ERROR, PLUGIN_ID,
						Status.ERROR, "Error loading LWJGL, OS: " + osname + "(" + osarch + "), native libs are searched in org.lwjgl plugin at " + base, ex);
				getLog().log(status);
				throw new BundleException(status.getMessage(), ex);
			}
		} else {
			Status status = new Status(Status.ERROR, PLUGIN_ID, Status.ERROR,
					"Error setting native libraries path. LWJGL not available for "
							+ osname + "(" + osarch + ")", null);
			getLog().log(status);
		}
		
	}

	/*
	 * (non-Javadoc)
	 * @see org.eclipse.core.runtime.Plugin#stop(org.osgi.framework.BundleContext)
	 */
	@Override
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 *
	 * @return the shared instance
	 */
	public static Activator getDefault() {
		return plugin;
	}

}
